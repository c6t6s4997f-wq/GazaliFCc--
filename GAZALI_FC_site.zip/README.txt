GAZALI FC
ملفات موقع كرة قدم بسيط.

طريقة النشر على GitHub:
1. ارفع index.html إلى مستودع GitHub.
2. افتح Settings ثم Pages.
3. من Build and deployment اختر Deploy from a branch.
4. اختر main و /(root)، ثم Save.
5. انتظر حتى يظهر رابط GitHub Pages.
